"use strict";
window.onload = function() {
	var sp = getSpotifyApi();
	var models = sp.require('$api/models');
	var views = sp.require("$api/views");
	var playerImage = new views.Player();

	// ---- Convert number to char
	function getChar(num) {
		var charSt = "";
		if (num != "") {
			charSt = String.fromCharCode(num);
		}
		return charSt;
	}

	// ---- Convert default Spotify URL to URI
	function getPlaylistURI(url) {
		var reg = new RegExp("/", "g");
		var parts = url.split(reg);
		return 'spotify:user:' + parts[4] + ':playlist:' + parts[6];
	}

	function getStarred(starred) {
		var s = '';
		if (starred == true) {
			s = '*';
		}
		return s;
	}

	function escapeChar(text, escChar) {
		var esc = getChar(escChar);
		var tOut = (text + '');
		// Single quote
		if (esc == "'") {
			var reg1 = new RegExp("(&apos;|')", "gi");
			tOut = (text +'').replace(reg1, "''");
		}
		// Double quote
		else if (esc == '"') {
			var reg1 = new RegExp("(&quot;|\")", "gi");
			tOut = (text +'').replace(reg1, '""');
		}
		
		return tOut;
	}
	
	$("#configuration").live("click", function(){
		if ($("#export").css("display") == "none") {
			$("#export").css("display", "table");
			$('#configuration').empty();
			$('#configuration').append('Settings <img src="img/icon_foldPlus.png" />');
		}
		else {
			$("#export").css("display", "none");
			$('#configuration').empty();
			$('#configuration').append('Settings <img src="img/icon_foldMinus.png" />');
		}
	});
	
	var drop = document.querySelector('#dropArea');
	
        drop.addEventListener('dragstart', function(e){
		e.dataTransfer.setData('text/html', this.innerHTML);
		e.dataTransfer.effectAllowed = 'copy';
        }, false);

        drop.addEventListener('dragenter', function(e){
		e.preventDefault();
		e.dataTransfer.dropEffect = 'copy';
		this.style.background = '#EEE';
		this.classList.add('over');
        }, false);

        drop.addEventListener('dragover', function(e){
		e.preventDefault();
		e.dataTransfer.dropEffect = 'copy';
		return false;
        }, false);

        drop.addEventListener('dragleave', function(e){
		e.preventDefault();
		this.style.background = '#FFF';
		this.classList.remove('over');
        }, false);

        drop.addEventListener('drop', function(e){
		e.preventDefault();
		this.classList.remove('over');
		this.style.background = '#FFF';
		var url = e.dataTransfer.getData('Text');
		var uri = getPlaylistURI(url);
		var fieldSep = $('#delimiter').val();
		var escChar = $('#textQualifier').val();
		var headerLine = $('#headerLine').val();
		var durationColumn = $('#durationColumn').val();
		var starredColumn = $('#starredColumn').val();
		var uriColumn = $('#uriColumn').val();
		$('#configuration').empty();
		$('#configuration').append('Settings <img src="img/icon_foldMinus.png" />');
		$('#export').css("display", "none");
		$('#dropArea').empty();

		var pl = models.Playlist.fromURI(uri, function(playlist) {
		    console.log('Playlist ' + playlist.name + ' loaded');
		});
		
		if (pl != null) {
			var tracks = pl.tracks;
			var size = tracks.length;
			var i = -1;
			var line = '';
			
			// ---- HEADER LINE ----
			var header = getChar(escChar) + "TRACK NAME" + getChar(escChar) +
						getChar(fieldSep) +
						getChar(escChar) + "ARTIST" + getChar(escChar) +
						getChar(fieldSep) +
						getChar(escChar) +"ALBUM NAME"+ getChar(escChar) +
						getChar(fieldSep);
			
				if (durationColumn == 'yes') {
					header += getChar(escChar) + "DURATION" + getChar(escChar) +
						getChar(fieldSep);
				}
				
				header += getChar(escChar) +"YEAR"+ getChar(escChar);
				
				if (starredColumn == 'yes') {
					header += getChar(fieldSep) + 				
						getChar(escChar) + "STARRED SONG" + getChar(escChar);
				}
				if (uriColumn == 'yes') {
					header += getChar(fieldSep) + 				
						getChar(escChar) + "URI" + getChar(escChar);
				}
				header += "\n";
			
			while(++i < size) {
				var artists = tracks[i].artists;
				var aSize = artists.length;
				var artistsStr = '';
				var j = -1;
				if (aSize > 1) {
					while(++j < aSize) {
						artistsStr += artists[j] + ', ';
					}
					artistsStr = artistsStr.slice(0, -2);
				}
				else {
					artistsStr = artists[0];
				}
				$('#playlistName').empty();
				$('#playlistName').append("Current playlist: " + pl.name + "<span id='playlistInfos'>&nbsp;(" + pl.length + " songs, " + pl.subscriberCount + " subscribers)</span>");
				
				// ---- LINE ----
				line += getChar(escChar) + escapeChar(tracks[i].name, escChar) + getChar(escChar) +
							getChar(fieldSep) +  
							getChar(escChar) + escapeChar(artistsStr, escChar) + getChar(escChar) +
							getChar(fieldSep) + 
							getChar(escChar) + escapeChar(tracks[i].album.name, escChar) + getChar(escChar) +
							getChar(fieldSep);
				
					if (durationColumn == 'yes') {
						line += getChar(escChar) + tracks[i].duration + getChar(escChar) +
							getChar(fieldSep);
					}

					line += getChar(escChar) + tracks[i].album.year + getChar(escChar);
					
					if (starredColumn == 'yes') {
						line += getChar(fieldSep) + 				
							getChar(escChar) + getStarred(tracks[i].starred) + getChar(escChar);
					}
					if (uriColumn == 'yes') {
						line += getChar(fieldSep) + 				
							getChar(escChar) + tracks[i].uri + getChar(escChar);
					}
					line += "\n";
				

			}
			
			if (headerLine == 'yes') {
				line = header + line;
			}
			$('#dropArea').append(line);
		}
        }, false);
};